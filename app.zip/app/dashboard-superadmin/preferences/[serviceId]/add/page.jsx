"use client";

import { useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { createPreferenceType } from "@/app/lib/api";
import toast from "react-hot-toast";

export default function AddPreferenceTypePage() {
    const { serviceId } = useParams();
    const router = useRouter();

    const [formData, setFormData] = useState({
        name: "",
        field_name: "",
        type: "single-select", // or "boolean", "number", "multi-select"
        description: "",
        is_required: false
    });
    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        console.log("[DEBUG] FormData before validation:", formData);

        // Defensive validation
        if (!formData.name.trim() || !formData.field_name.trim()) {
            toast.error("Name and Field Name cannot be empty.");
            console.log("[DEBUG] Validation failed: Name or Field Name empty.");
            return;
        }

        const validTypes = ["single-select", "multi-select", "number", "boolean"];
        if (!validTypes.includes(formData.type)) {
            toast.error("Type must be one of: single-select, multi-select, number, boolean.");
            console.log("[DEBUG] Validation failed: Invalid type selected.", formData.type);
            return;
        }

        if (!serviceId) {
            toast.error("Service ID is missing from URL.");
            console.log("[DEBUG] Missing serviceId from useParams.");
            return;
        }

        setLoading(true);
        try {
            const payload = {
                name: formData.name.trim(),
                field_name: formData.field_name.trim(),
                type: formData.type,
                description: formData.description.trim() || null,
                is_required: formData.is_required,
                display_order: 0,
                is_active: true,
                service_id: serviceId
            };

            console.log("[DEBUG] Sending payload to createPreferenceType:", payload);

            const response = await createPreferenceType(payload);

            console.log("[DEBUG] createPreferenceType response:", response);

            toast.success("Preference type created successfully.");
            router.push(`/dashboard-superadmin/preferences/${serviceId}`);
        } catch (error) {
            console.error("[DEBUG] Error in createPreferenceType:", error);
            const details = error.response?.data?.details;
            if (details && Array.isArray(details)) {
                details.forEach(msg => toast.error(msg));
                console.log("[DEBUG] API validation errors from backend:", details);
            } else {
                toast.error("Failed to create preference type.");
                console.log("[DEBUG] General API error:", error.response?.data || error.message);
            }
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ padding: "20px" }}>
            <h2>Create New Preference Type</h2>
            <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "12px", maxWidth: "400px" }}>
                <input
                    type="text"
                    name="name"
                    placeholder="Preference Name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="field_name"
                    placeholder="Field Name (e.g., workers)"
                    value={formData.field_name}
                    onChange={handleChange}
                    required
                />
                <textarea
                    name="description"
                    placeholder="Description"
                    value={formData.description}
                    onChange={handleChange}
                />
                <label>
                    <input
                        type="checkbox"
                        name="is_required"
                        checked={formData.is_required}
                        onChange={handleChange}
                    /> Required
                </label>
                <label>Preference Type:</label>
                <select name="type" value={formData.type} onChange={handleChange}>
                    <option value="single-select">single-select</option>
                    <option value="multi-select">multi-select</option>
                    <option value="boolean">boolean</option>
                    <option value="number">number</option>
                </select>
                <button type="submit" disabled={loading}>
                    {loading ? "Creating..." : "Create Preference Type"}
                </button>
            </form>
        </div>
    );
}
