"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import { getPreferenceOptionById, updatePreferenceOption } from "@/app/lib/api";
import toast from "react-hot-toast";

export default function EditPreferenceOptionPage() {
    const { serviceId, optionId } = useParams();
    const router = useRouter();

    const [formData, setFormData] = useState({
        value: "",
        display_name: "",
        description: "",
        is_default: false
    });
    const [loading, setLoading] = useState(true);
    const [updating, setUpdating] = useState(false);

    const fetchOption = async () => {
        setLoading(true);
        try {
            console.log("[DEBUG] Fetching option with ID:", optionId);
            const res = await getPreferenceOptionById(optionId);
            const option = res.data?.data;

            if (!option) {
                toast.error("Option not found.");
                router.push(`/dashboard-superadmin/preferences/${serviceId}`);
                return;
            }

            setFormData({
                value: option.value || "",
                display_name: option.display_name || "",
                description: option.description || "",
                is_default: option.is_default || false
            });
            console.log("[DEBUG] Fetched option data:", option);
        } catch (error) {
            console.error("[DEBUG] Error fetching option:", error);
            toast.error("Failed to fetch option data.");
            router.push(`/dashboard-superadmin/preferences/${serviceId}`);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (optionId) {
            fetchOption();
        }
    }, [optionId]);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formData.value.trim() || !formData.display_name.trim()) {
            toast.error("Value and Display Name cannot be empty.");
            console.log("[DEBUG] Validation failed:", formData);
            return;
        }

        setUpdating(true);
        try {
            const payload = {
                value: formData.value.trim(),
                display_name: formData.display_name.trim(),
                description: formData.description.trim() || null,
                is_default: formData.is_default,
                display_order: 0,
                is_active: true
            };

            console.log("[DEBUG] Sending update payload:", payload);

            const res = await updatePreferenceOption(optionId, payload);
            console.log("[DEBUG] Update response:", res.data);

            toast.success("Preference option updated successfully.");
            router.push(`/dashboard-superadmin/preferences/${serviceId}`);
        } catch (error) {
            console.error("[DEBUG] Error updating preference option:", error);
            const details = error.response?.data?.details;
            if (details && Array.isArray(details)) {
                details.forEach(msg => toast.error(msg));
            } else {
                toast.error("Failed to update preference option.");
            }
        } finally {
            setUpdating(false);
        }
    };

    return (
        <div style={{ padding: "20px" }}>
            <h2>Edit Preference Option</h2>
            {loading ? (
                <p>Loading option data...</p>
            ) : (
                <form
                    onSubmit={handleSubmit}
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "12px",
                        maxWidth: "400px"
                    }}
                >
                    <input
                        type="text"
                        name="value"
                        placeholder="Value"
                        value={formData.value}
                        onChange={handleChange}
                        required
                    />
                    <input
                        type="text"
                        name="display_name"
                        placeholder="Display Name"
                        value={formData.display_name}
                        onChange={handleChange}
                        required
                    />
                    <textarea
                        name="description"
                        placeholder="Description"
                        value={formData.description}
                        onChange={handleChange}
                    />
                    <label>
                        <input
                            type="checkbox"
                            name="is_default"
                            checked={formData.is_default}
                            onChange={handleChange}
                        />{" "}
                        Default Option
                    </label>
                    <button type="submit" disabled={updating}>
                        {updating ? "Updating..." : "Update Preference Option"}
                    </button>
                </form>
            )}
        </div>
    );
}
