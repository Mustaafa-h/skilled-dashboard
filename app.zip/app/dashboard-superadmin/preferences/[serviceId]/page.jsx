"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import {
  getServiceById,
  getPreferenceTypesByServiceId,
  deletePreferenceType,
  deletePreferenceOption,
} from "@/app/lib/api";
import toast from "react-hot-toast";
import Link from "next/link";
import styles from "@/app/ui/superadmin/preferences/[serviceId]/page.module.css";
import { useTranslations } from "next-intl";

export default function ServicePreferencesPage() {
  const { serviceId } = useParams();
  const router = useRouter();
  const t = useTranslations("servicePreferences");

  const [service, setService] = useState(null);
  const [preferences, setPreferences] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [serviceRes, prefsRes] = await Promise.all([
        getServiceById(serviceId),
        getPreferenceTypesByServiceId(serviceId),
      ]);
      setService(serviceRes.data.data);

      const cleanedPrefs = (prefsRes.data.data || []).map((pref) => ({
        ...pref,
        options: (pref.options || []).filter(
          (opt) => opt && opt.id && opt.is_active !== false
        ),
      }));
      setPreferences(cleanedPrefs);
    } catch (error) {
      console.error(error);
      toast.error(t("loadFail", { defaultValue: "Failed to load service preferences." }));
    } finally {
      setLoading(false);
    }
  }, [serviceId, t]);

  useEffect(() => {
    if (serviceId) fetchData();
  }, [serviceId, fetchData]);

  const handleDeletePrefType = async (prefTypeId) => {
    if (!confirm(t("deletePrefTypeConfirm", { defaultValue: "Delete this preference type and its options?" }))) return;
    try {
      await deletePreferenceType(prefTypeId);
      toast.success(t("deletePrefTypeSuccess", { defaultValue: "Preference type deleted." }));
      fetchData();
    } catch (error) {
      console.error(error);
      toast.error(t("deletePrefTypeFail", { defaultValue: "Failed to delete preference type." }));
      fetchData();
    }
  };

  const handleDeleteOption = async (optionId) => {
    if (!confirm(t("deleteOptionConfirm", { defaultValue: "Delete this preference option?" }))) return;
    try {
      await deletePreferenceOption(optionId);
      toast.success(t("deleteOptionSuccess", { defaultValue: "Preference option deleted." }));
      fetchData();
    } catch (error) {
      console.error(error);
      toast.error(t("deleteOptionFail", { defaultValue: "Failed to delete option." }));
      fetchData();
    }
  };

  if (loading) return <p>{t("loading", { defaultValue: "Loading preferences..." })}</p>;
  if (!service) return <p>{t("notFound", { defaultValue: "Service not found." })}</p>;

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>
        {t("title", { name: service.name, defaultValue: "Preferences for: {name}" })}
      </h2>
      <p className={styles.description}>{service.description || t("noDescription", { defaultValue: "No description provided." })}</p>

      <button
        onClick={() => router.push(`/dashboard-superadmin/preferences/${serviceId}/add`)}
        className={styles.addButton}
      >
        {t("createNew", { defaultValue: "+ Create New Preference Type" })}
      </button>

      {preferences.length === 0 ? (
        <p>{t("noPreferences", { defaultValue: "No preferences found for this service." })}</p>
      ) : (
        preferences.map((pref) => (
          <div key={pref.id} className={styles.card}>
            <h3 className={styles.prefName}>{pref.name}</h3>
            <p className={styles.prefDescription}>{pref.description || t("noDescription", { defaultValue: "No description provided." })}</p>

            <div className={styles.buttonGroup}>
              <Link href={`/dashboard-superadmin/preferences/${serviceId}/edit/${pref.id}`}>
                <button className={styles.button}>{t("editType", { defaultValue: "Edit Type" })}</button>
              </Link>
              <button
                onClick={() => handleDeletePrefType(pref.id)}
                className={`${styles.button} ${styles.deleteButton}`}
              >
                {t("deleteType", { defaultValue: "Delete Type" })}
              </button>
              <Link href={`/dashboard-superadmin/preferences/${serviceId}/add-option/${pref.id}`}>
                <button className={styles.button}>{t("addOption", { defaultValue: "+ Add Option" })}</button>
              </Link>
            </div>

            <h4 className={styles.optionsTitle}>{t("optionsTitle", { defaultValue: "Options:" })}</h4>
            {pref.options.length === 0 ? (
              <p className={styles.noOptions}>{t("noOptions", { defaultValue: "No options available." })}</p>
            ) : (
              <ul className={styles.optionList}>
                {pref.options.map((option) => (
                  <li key={option.id} className={styles.optionItem}>
                    {option.display_name} - {option.description || t("noDescription", { defaultValue: "No description provided." })}
                    <div className={styles.optionButtonGroup}>
                      <Link
                        href={`/dashboard-superadmin/preferences/${serviceId}/edit-option/${option.id}`}
                      >
                        <button className={styles.button}>{t("editOption", { defaultValue: "Edit Option" })}</button>
                      </Link>
                      <button
                        onClick={() => handleDeleteOption(option.id)}
                        className={`${styles.button} ${styles.deleteButton}`}
                      >
                        {t("deleteOption", { defaultValue: "Delete Option" })}
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))
      )}
    </div>
  );
}
