"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import {
    getServiceById,
    getPreferenceTypesByServiceId,
    deletePreferenceType,
    deletePreferenceOption
} from "@/app/lib/api";
import toast from "react-hot-toast";
import Link from "next/link";

export default function ServicePreferencesPage() {
    const { serviceId } = useParams();
    const router = useRouter();

    const [service, setService] = useState(null);
    const [preferences, setPreferences] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchData = async () => {
        setLoading(true);
        try {
            const [serviceRes, prefsRes] = await Promise.all([
                getServiceById(serviceId),
                getPreferenceTypesByServiceId(serviceId)
            ]);
            setService(serviceRes.data.data);

            // Defensive filtering to hide stale/deleted options
            const cleanedPrefs = (prefsRes.data.data || []).map(pref => ({
                ...pref,
                options: (pref.options || [])
                    .filter(opt => opt && opt.id && opt.is_active !== false)
            }));
            setPreferences(cleanedPrefs);
        } catch (error) {
            console.error(error);
            toast.error("Failed to load service preferences.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (serviceId) fetchData();
    }, [serviceId]);

    const handleDeletePrefType = async (prefTypeId) => {
        if (!confirm("Delete this preference type and its options?")) return;
        try {
            await deletePreferenceType(prefTypeId);
            toast.success("Preference type deleted.");
            fetchData();
        } catch (error) {
            console.error(error);
            toast.error("Failed to delete preference type.");
            fetchData(); // Refresh in case partially deleted
        }
    };

    const handleDeleteOption = async (optionId) => {
        if (!confirm("Delete this preference option?")) return;
        try {
            await deletePreferenceOption(optionId);
            toast.success("Preference option deleted.");
            fetchData();
        } catch (error) {
            console.error(error);
            toast.error("Failed to delete option.");
            fetchData(); // Refresh in case partially deleted
        }
    };

    if (loading) return <p>Loading preferences...</p>;
    if (!service) return <p>Service not found.</p>;

    return (
        <div style={{ padding: "20px" }}>
            <h2>Preferences for: {service.name}</h2>
            <p>{service.description || "No description provided."}</p>

            <button
                onClick={() => router.push(`/dashboard-superadmin/preferences/${serviceId}/add`)}
                style={{ marginTop: "16px", marginBottom: "24px" }}
            >
                + Create New Preference Type
            </button>

            {preferences.length === 0 ? (
                <p>No preferences found for this service.</p>
            ) : (
                preferences.map((pref) => (
                    <div
                        key={pref.id}
                        style={{
                            border: "1px solid #444",
                            borderRadius: "8px",
                            padding: "12px",
                            marginBottom: "16px",
                            background: "#121212",
                            color: "white"
                        }}
                    >
                        <h3>{pref.name}</h3>
                        <p>{pref.description || "No description provided."}</p>

                        <div style={{ display: "flex", gap: "10px", marginTop: "8px" }}>
                            <Link href={`/dashboard-superadmin/preferences/${serviceId}/edit/${pref.id}`}>
                                <button>Edit Type</button>
                            </Link>
                            <button onClick={() => handleDeletePrefType(pref.id)}>Delete Type</button>
                            <Link href={`/dashboard-superadmin/preferences/${serviceId}/add-option/${pref.id}`}>
                                <button>+ Add Option</button>
                            </Link>
                        </div>

                        <h4 style={{ marginTop: "12px" }}>Options:</h4>
                        {pref.options.length === 0 ? (
                            <p style={{ color: "#aaa" }}>No options available.</p>
                        ) : (
                            <ul style={{ marginLeft: "20px" }}>
                                {pref.options.map((option) => (
                                    <li key={option.id} style={{ marginBottom: "4px" }}>
                                        {option.display_name} - {option.description || "No description"}
                                        <div style={{ display: "inline-flex", gap: "8px", marginLeft: "10px" }}>
                                            <Link href={`/dashboard-superadmin/preferences/${serviceId}/edit-option/${option.id}`}>
                                                <button>Edit Option</button>
                                            </Link>
                                            <button onClick={() => handleDeleteOption(option.id)}>Delete Option</button>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                ))
            )}
        </div>
    );
}
