"use client";

import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { getPreferenceTypeById, updatePreferenceType } from "@/app/lib/api";
import toast from "react-hot-toast";

export default function EditPreferenceTypePage() {
    const { serviceId, prefTypeId } = useParams();
    const router = useRouter();

    const [formData, setFormData] = useState({
        name: "",
        field_name: "",
        type: "single-select", // or "multi-select", "number", "boolean"
        description: "",
        is_required: false
    });
    const [loading, setLoading] = useState(true);
    const [updating, setUpdating] = useState(false);

    useEffect(() => {
        const fetchType = async () => {
            try {
                console.log("[DEBUG] Fetching preference type:", prefTypeId);
                const res = await getPreferenceTypeById(prefTypeId);
                const data = res.data.data;
                console.log("[DEBUG] Fetched preference type data:", data);

                setFormData({
                    name: data.name || "",
                    field_name: data.field_name || "",
                    type: data.type || "single-select",
                    description: data.description || "",
                    is_required: data.is_required || false
                });
            } catch (error) {
                console.error("[DEBUG] Error fetching preference type:", error);
                toast.error("Failed to fetch preference type.");
                router.push(`/dashboard-superadmin/preferences/${serviceId}`);
            } finally {
                setLoading(false);
            }
        };

        if (prefTypeId) fetchType();
    }, [prefTypeId, router, serviceId]);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === "checkbox" ? checked : value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formData.name.trim() || !formData.field_name.trim()) {
            toast.error("Name and Field Name cannot be empty.");
            return;
        }

        const validTypes = ["single-select", "multi-select", "number", "boolean"];
        if (!validTypes.includes(formData.type)) {
            toast.error("Invalid type.");
            return;
        }

        setUpdating(true);
        try {
            const payload = {
                name: formData.name.trim(),
                field_name: formData.field_name.trim(),
                type: formData.type,
                description: formData.description.trim() || null,
                is_required: formData.is_required,
                display_order: 0,
                is_active: true
            };

            console.log("[DEBUG] Sending update payload:", payload);

            await updatePreferenceType(prefTypeId, payload);
            toast.success("Preference type updated successfully.");
            router.push(`/dashboard-superadmin/preferences/${serviceId}`);
        } catch (error) {
            console.error("[DEBUG] Error updating preference type:", error);
            const details = error.response?.data?.details;
            if (details && Array.isArray(details)) {
                details.forEach(msg => toast.error(msg));
            } else {
                toast.error("Failed to update preference type.");
            }
        } finally {
            setUpdating(false);
        }
    };

    return (
        <div style={{ padding: "20px" }}>
            <h2>Edit Preference Type</h2>
            {loading ? (
                <p>Loading preference type data...</p>
            ) : (
                <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "12px", maxWidth: "400px" }}>
                    <input
                        type="text"
                        name="name"
                        placeholder="Preference Name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                    />
                    <input
                        type="text"
                        name="field_name"
                        placeholder="Field Name"
                        value={formData.field_name}
                        onChange={handleChange}
                        required
                    />
                    <textarea
                        name="description"
                        placeholder="Description"
                        value={formData.description}
                        onChange={handleChange}
                    />
                    <label>
                        <input
                            type="checkbox"
                            name="is_required"
                            checked={formData.is_required}
                            onChange={handleChange}
                        /> Required
                    </label>
                    <label>Preference Type:</label>
                    <select name="type" value={formData.type} onChange={handleChange}>
                        <option value="single-select">Single Select</option>
                        <option value="multi-select">Multi Select</option>
                        <option value="boolean">Boolean</option>
                        <option value="number">Number</option>
                    </select>
                    <button type="submit" disabled={updating}>
                        {updating ? "Updating..." : "Update Preference Type"}
                    </button>
                </form>
            )}
        </div>
    );
}
