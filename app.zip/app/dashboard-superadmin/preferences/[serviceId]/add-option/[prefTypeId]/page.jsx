"use client";

import { useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { createPreferenceOption } from "@/app/lib/api";
import toast from "react-hot-toast";

export default function AddPreferenceOptionPage() {
    const { serviceId, prefTypeId } = useParams();
    const router = useRouter();

    const [formData, setFormData] = useState({
        value: "",
        display_name: "",
        description: "",
        is_default: false
    });
    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Defensive validation
        if (!formData.value || typeof formData.value !== "string" || !formData.value.trim()) {
            toast.error("Value must be a non-empty string.");
            console.log("[DEBUG] Invalid value field:", formData.value);
            return;
        }
        if (!formData.display_name || typeof formData.display_name !== "string" || !formData.display_name.trim()) {
            toast.error("Display Name must be a non-empty string.");
            console.log("[DEBUG] Invalid display_name field:", formData.display_name);
            return;
        }

        setLoading(true);
        try {
            const payload = {
                preference_type_id: prefTypeId,
                value: String(formData.value).trim(),
                display_name: String(formData.display_name).trim(),
                description: formData.description?.trim() || null,
                is_default: formData.is_default,
                display_order: 0,
                is_active: true
            };

            console.log("[DEBUG] Sending payload to createPreferenceOption:", payload);

            const response = await createPreferenceOption(payload);
            console.log("[DEBUG] Successfully created option:", response.data);

            toast.success("Preference option created successfully.");
            router.push(`/dashboard-superadmin/preferences/${serviceId}`);
        } catch (error) {
            console.error("[DEBUG] Error during createPreferenceOption:", error);
            const details = error.response?.data?.details;
            if (details && Array.isArray(details)) {
                details.forEach((msg) => toast.error(msg));
            } else {
                toast.error("Failed to create preference option. Check console for details.");
            }
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ padding: "20px" }}>
            <h2>Create New Preference Option</h2>
            <form
                onSubmit={handleSubmit}
                style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "12px",
                    maxWidth: "400px"
                }}
            >
                <input
                    type="text"
                    name="value"
                    placeholder="Value (e.g., '3')"
                    value={formData.value}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="display_name"
                    placeholder="Display Name (e.g., '3 Workers')"
                    value={formData.display_name}
                    onChange={handleChange}
                    required
                />
                <textarea
                    name="description"
                    placeholder="Description"
                    value={formData.description}
                    onChange={handleChange}
                />
                <label>
                    <input
                        type="checkbox"
                        name="is_default"
                        checked={formData.is_default}
                        onChange={handleChange}
                    />{" "}
                    Default Option
                </label>
                <button type="submit" disabled={loading}>
                    {loading ? "Creating..." : "Create Preference Option"}
                </button>
            </form>
        </div>
    );
}
