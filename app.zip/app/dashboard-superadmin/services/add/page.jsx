"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createService } from "@/app/lib/api";
import toast from "react-hot-toast";

export default function AddServicePage() {
    const router = useRouter();
    const [formData, setFormData] = useState({
        name: "",
        slug: "",
        description: "",
        icon_url: "",
        image_url: "",
        sort_order: 0,
        is_active: true
    });
    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === "checkbox" ? checked : value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await createService(formData);
            toast.success("Service created successfully.");
            router.push("/dashboard-superadmin/services");
        } catch (error) {
            console.error("Error creating service:", error);
            toast.error("Failed to create service.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ maxWidth: "600px", margin: "0 auto", padding: "20px" }}>
            <h1>Create New Service</h1>
            <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                <input
                    type="text"
                    name="name"
                    placeholder="Service Name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="slug"
                    placeholder="Slug"
                    value={formData.slug}
                    onChange={handleChange}
                    required
                />
                <textarea
                    name="description"
                    placeholder="Description"
                    value={formData.description}
                    onChange={handleChange}
                    required
                />
                <input
                    type="url"
                    name="icon_url"
                    placeholder="Icon URL"
                    value={formData.icon_url}
                    onChange={handleChange}
                />
                <input
                    type="url"
                    name="image_url"
                    placeholder="Image URL"
                    value={formData.image_url}
                    onChange={handleChange}
                />
                <input
                    type="number"
                    name="sort_order"
                    placeholder="Sort Order"
                    value={formData.sort_order}
                    onChange={handleChange}
                />
                <label>
                    <input
                        type="checkbox"
                        name="is_active"
                        checked={formData.is_active}
                        onChange={handleChange}
                    />{" "}
                    Active
                </label>
                <button type="submit" disabled={loading}>
                    {loading ? "Creating..." : "Create Service"}
                </button>
            </form>
        </div>
    );
}
