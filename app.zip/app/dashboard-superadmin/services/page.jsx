"use client";

import { useEffect, useState } from "react";
import { getAllServices, deleteService, getAllSubServices, deleteSubService } from "@/app/lib/api";
import { useRouter } from "next/navigation";
import Link from "next/link";
import toast from "react-hot-toast";

export default function SuperAdminServicesPage() {
    const [services, setServices] = useState([]);
    const [subServices, setSubServices] = useState([]);
    const [loading, setLoading] = useState(true);
    const router = useRouter();

    useEffect(() => {
        const fetchServices = async () => {
            try {
                const [servicesRes, subServicesRes] = await Promise.all([
                    getAllServices(),
                    getAllSubServices()
                ]);
                setServices(servicesRes.data.data || []);
                setSubServices(subServicesRes.data.data || []);
            } catch (error) {
                console.error("Error fetching services:", error);
                toast.error("Failed to fetch services.");
            } finally {
                setLoading(false);
            }
        };
        fetchServices();
    }, []);

    const handleDeleteService = async (id) => {
        if (!confirm("Are you sure you want to delete this service?")) return;
        try {
            await deleteService(id);
            toast.success("Service deleted successfully.");
            setServices((prev) => prev.filter((s) => s.id !== id));
        } catch (error) {
            console.error("Error deleting service:", error);
            toast.error("Failed to delete service.");
        }
    };

    const handleDeleteSubService = async (subId) => {
        if (!confirm("Are you sure you want to delete this sub-service?")) return;
        try {
            await deleteSubService(subId);
            toast.success("Sub-service deleted successfully.");
            setSubServices((prev) => prev.filter((sub) => sub.id !== subId));
        } catch (error) {
            console.error("Error deleting sub-service:", error);
            toast.error("Failed to delete sub-service.");
        }
    };

    const handleAddService = () => {
        router.push("/dashboard-superadmin/services/add");
    };

    return (
        <div>
            <h1>Services Management</h1>
            <button onClick={handleAddService}>+ Create Service</button>

            {loading ? (
                <p>Loading services...</p>
            ) : services.length === 0 ? (
                <p>No services found.</p>
            ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: "20px", marginTop: "20px" }}>
                    {services.map((service) => (
                        <div key={service.id} style={{ border: "1px solid white", padding: "10px" }}>
                            <h2>{service.name}</h2>
                            <p>{service.description || "No description provided."}</p>
                            <div style={{ display: "flex", gap: "10px", marginBottom: "10px" }}>
                                <Link href={`/dashboard-superadmin/services/${service.id}/edit`}>
                                    <button>Edit</button>
                                </Link>
                                <button onClick={() => handleDeleteService(service.id)}>Delete</button>
                                <Link href={`/dashboard-superadmin/services/${service.id}/add-sub`}>
                                    <button>+ Add Sub-Service</button>
                                </Link>
                            </div>

                            <p><strong>Sub-Services:</strong></p>
                            <ul style={{ listStyle: "none", paddingLeft: "0" }}>
                                {subServices.filter((sub) => sub.service_id === service.id).length > 0 ? (
                                    subServices
                                        .filter((sub) => sub.service_id === service.id)
                                        .map((sub) => (
                                            <li key={sub.id} style={{ border: "1px solid gray", padding: "8px", marginBottom: "5px" }}>
                                                <div>
                                                    <strong>{sub.name}</strong> - {sub.description || "No description"}
                                                </div>
                                                <div style={{ display: "flex", gap: "8px", marginTop: "5px" }}>
                                                    <Link href={`/dashboard-superadmin/services/${service.id}/edit-sub/${sub.id}`}>
                                                        <button>Edit Sub</button>
                                                    </Link>
                                                    <button onClick={() => handleDeleteSubService(sub.id)}>Delete Sub</button>
                                                </div>
                                            </li>
                                        ))
                                ) : (
                                    <li>No sub-services for this service.</li>
                                )}
                            </ul>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}
