"use client";

import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import toast from "react-hot-toast";
import { getServiceById, updateService } from "@/app/lib/api";

export default function EditServicePage() {
    const router = useRouter();
    const { serviceId } = useParams();

    const [loading, setLoading] = useState(true);
    const [formData, setFormData] = useState({
        name: "",
        slug: "",
        description: "",
        icon_url: "",
        image_url: "",
        is_active: true
    });

    useEffect(() => {
        const fetchService = async () => {
            try {
                const response = await getServiceById(serviceId);
                const data = response.data?.data;
                if (data) {
                    setFormData({
                        name: data.name || "",
                        slug: data.slug || "",
                        description: data.description || "",
                        icon_url: data.icon_url || "",
                        image_url: data.image_url || "",
                        is_active: data.is_active ?? true
                    });
                }
            } catch (error) {
                console.error("Error fetching service:", error);
                toast.error("Failed to fetch service data.");
            } finally {
                setLoading(false);
            }
        };

        fetchService();
    }, [serviceId]);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === "checkbox" ? checked : value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            const response = await updateService(serviceId, formData);
            if (response.data?.success) {
                toast.success("Service updated successfully.");
                router.push("/dashboard-superadmin/services");
            } else {
                toast.error(response.data?.message || "Failed to update service.");
            }
        } catch (error) {
            console.error("Error updating service:", error);
            toast.error("Error updating service.");
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <p>Loading...</p>;

    return (
        <div>
            <h1>Edit Service</h1>
            <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                <input
                    type="text"
                    name="name"
                    placeholder="Service Name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="slug"
                    placeholder="Slug"
                    value={formData.slug}
                    onChange={handleChange}
                    required
                />
                <textarea
                    name="description"
                    placeholder="Description"
                    value={formData.description}
                    onChange={handleChange}
                />
                <input
                    type="url"
                    name="icon_url"
                    placeholder="Icon URL"
                    value={formData.icon_url}
                    onChange={handleChange}
                />
                <input
                    type="url"
                    name="image_url"
                    placeholder="Image URL"
                    value={formData.image_url}
                    onChange={handleChange}
                />
                <label>
                    <input
                        type="checkbox"
                        name="is_active"
                        checked={formData.is_active}
                        onChange={handleChange}
                    />{" "}
                    Active
                </label>
                <button type="submit" disabled={loading}>
                    {loading ? "Updating..." : "Update Service"}
                </button>
            </form>
        </div>
    );
}
