"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { getCompany } from "@/app/lib/api";
import GallerySection from "./gallery/GallerySection";

export default function SingleCompanyPage() {
    const { companyId } = useParams();
    const router = useRouter();
    const [company, setCompany] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchCompany = async () => {
            try {
                const res = await getCompany(companyId);
                setCompany(res.data.data);
            } catch (err) {
                console.error("Error fetching company:", err);
            } finally {
                setLoading(false);
            }
        };
        fetchCompany();
    }, [companyId]);

    if (loading) return <p>Loading company data...</p>;
    if (!company) return <p>Company not found.</p>;

    return (
        <div>
            <h1>{company.name}</h1>

            {/* Action Buttons */}
            <div style={{ display: "flex", gap: "10px", margin: "20px 0" }}>
                <button
                    onClick={() =>
                        router.push(`/dashboard-superadmin/companies/${companyId}/workers`)
                    }
                >
                    Manage Workers
                </button>
                <button
                    onClick={() =>
                        router.push(`/dashboard-superadmin/companies/${companyId}/services`)
                    }
                >
                    Manage Services
                </button>
                <button
                    onClick={() =>
                        router.push(`/dashboard-superadmin/companies/${companyId}/preferences`)
                    }
                >
                    Manage Preferences
                </button>
            </div>

            {/* Basic Company Overview */}
            <div>
                <p><strong>About:</strong> {company.about || "N/A"}</p>
                <p><strong>Website:</strong> {company.website_url || "N/A"}</p>
                <p><strong>Price Range:</strong> {company.price_range || "N/A"}</p>
                <p><strong>Status:</strong> {company.status || "N/A"}</p>
                <p><strong>Created At:</strong> {new Date(company.created_at).toLocaleString()}</p>
                <p><strong>Updated At:</strong> {new Date(company.updated_at).toLocaleString()}</p>
            </div>
            <GallerySection companyId={company.id} />
        </div>


    );
}
