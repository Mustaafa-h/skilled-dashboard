"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { addCompanyWorker } from "@/app/lib/api";
import toast from "react-hot-toast";

export default function AddWorkerPage() {
    const { companyId } = useParams();
    const router = useRouter();

    const [formData, setFormData] = useState({
        full_name: "",
        nationality: "",
        phone: "",
        gender: "male",
    });

    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            await addCompanyWorker(companyId, formData);
            toast.success("Worker added successfully.");
            router.push(`/dashboard-superadmin/companies/${companyId}/workers`);
        } catch (error) {
            console.error("Error adding worker:", error);
            toast.error("Failed to add worker.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <h1>Add New Worker</h1>
            <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "12px", maxWidth: "400px" }}>
                <input
                    type="text"
                    name="full_name"
                    placeholder="Full Name"
                    value={formData.full_name}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="nationality"
                    placeholder="Nationality"
                    value={formData.nationality}
                    onChange={handleChange}
                />
                <input
                    type="text"
                    name="phone"
                    placeholder="Phone"
                    value={formData.phone}
                    onChange={handleChange}
                />
                <select name="gender" value={formData.gender} onChange={handleChange}>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                </select>

                <button type="submit" disabled={loading}>
                    {loading ? "Adding..." : "Add Worker"}
                </button>
            </form>
        </div>
    );
}
