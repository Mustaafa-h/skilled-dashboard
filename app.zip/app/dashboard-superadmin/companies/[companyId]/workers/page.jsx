"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import {
    getCompanyWorkers,
    deleteCompanyWorker
} from "@/app/lib/api";
import toast from "react-hot-toast";

export default function CompanyWorkersPage() {
    const { companyId } = useParams();
    const router = useRouter();
    const [workers, setWorkers] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchWorkers = async () => {
        try {
            const res = await getCompanyWorkers(companyId);
            setWorkers(res.data.data || []);
        } catch (err) {
            console.error("Error fetching workers:", err);
            toast.error("Failed to fetch workers.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchWorkers();
    }, [companyId]);

    const handleDeleteWorker = async (workerId) => {
        if (!confirm("Are you sure you want to delete this worker?")) return;
        try {
            await deleteCompanyWorker(workerId);
            toast.success("Worker deleted successfully.");
            fetchWorkers();
        } catch (err) {
            console.error("Error deleting worker:", err);
            toast.error("Failed to delete worker.");
        }
    };

    const handleAddWorker = () => {
        router.push(`/dashboard-superadmin/companies/${companyId}/workers/add`);
    };

    return (
        <div>
            <h1>Company Workers</h1>
            <button
                onClick={handleAddWorker}
                style={{
                    padding: "8px 16px",
                    background: "#2563eb",
                    color: "#fff",
                    border: "none",
                    borderRadius: "4px",
                    cursor: "pointer",
                    margin: "10px 0"
                }}
            >
                + Add Worker
            </button>

            {loading ? (
                <p>Loading workers...</p>
            ) : workers.length === 0 ? (
                <p>No workers found for this company.</p>
            ) : (
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "16px" }}>
                    {workers.map((worker) => (
                        <div
                            key={worker.id}
                            style={{
                                border: "1px solid #ccc",
                                borderRadius: "8px",
                                padding: "12px",

                            }}
                        >
                            <p><strong>Name:</strong> {worker.full_name}</p>
                            <p><strong>Phone:</strong> {worker.phone}</p>
                            <p><strong>Nationality:</strong> {worker.nationality}</p>
                            <p><strong>Gender:</strong> {worker.gender}</p>
                            <p><strong>Status:</strong> {worker.is_active ? "Active" : "Inactive"}</p>
                            <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
                                <button
                                    onClick={() =>
                                        router.push(`/dashboard-superadmin/companies/${companyId}/workers/edit/${worker.id}`)
                                    }
                                    style={{
                                        padding: "6px 12px",
                                        background: "#4caf50",
                                        color: "#fff",
                                        border: "none",
                                        borderRadius: "4px",
                                        cursor: "pointer"
                                    }}
                                >
                                    Edit
                                </button>
                                <button
                                    onClick={() => handleDeleteWorker(worker.id)}
                                    style={{
                                        padding: "6px 12px",
                                        background: "#e53935",
                                        color: "#fff",
                                        border: "none",
                                        borderRadius: "4px",
                                        cursor: "pointer"
                                    }}
                                >
                                    Delete
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}
