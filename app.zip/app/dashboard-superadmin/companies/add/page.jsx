"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createCompany } from "@/app/lib/api";
import toast from "react-hot-toast";
import styles from "@/app/ui/superadmin/shared/form.module.css";
import dynamic from "next/dynamic";
import { useTranslations } from "next-intl";

const MapPicker = dynamic(() => import("@/app/ui/map/MapPicker"), { ssr: false });

export default function AddCompanyPage() {
  const t = useTranslations();
  const router = useRouter();

  const [formData, setFormData] = useState({
    name: "",
    about: "",
    price_range: "medium",
    owner_id: "",
  });

  const [location, setLocation] = useState({ lat: 33.3152, lng: 44.3661 });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const body = {
        ...formData,
        lat: location.lat,
        long: location.lng,
        status: "pending"
        // 🔥 Do NOT include is_verified or website_url
      };

      const response = await createCompany(body);

      if (response.data.success) {
        toast.success(t("addCompany.success", { defaultValue: "Company created successfully!" }));
        router.push("/dashboard-superadmin/companies");
      } else {
        toast.error(response.data.message || t("addCompany.error", { defaultValue: "Failed to create company" }));
      }
    } catch (error) {
      console.error(error);
      toast.error(
        error.response?.data?.message ||
        t("addCompany.genericError", { defaultValue: "An error occurred while creating the company." })
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>{t("addCompany.title", { defaultValue: "Add New Company" })}</h1>
      <form onSubmit={handleSubmit} className={styles.form}>
        <input
          type="text"
          name="name"
          placeholder={t("addCompany.namePlaceholder", { defaultValue: "Company Name" })}
          value={formData.name}
          onChange={handleChange}
          required
          className={styles.input}
        />
        <textarea
          name="about"
          placeholder={t("addCompany.aboutPlaceholder", { defaultValue: "About the company" })}
          value={formData.about}
          onChange={handleChange}
          required
          className={styles.textarea}
        />
        <select
          name="price_range"
          value={formData.price_range}
          onChange={handleChange}
          className={styles.select}
        >
          <option value="low">{t("Price.low", { defaultValue: "Low" })}</option>
          <option value="medium">{t("Price.medium", { defaultValue: "Medium" })}</option>
          <option value="high">{t("Price.high", { defaultValue: "High" })}</option>
        </select>
        <input
          type="text"
          name="owner_id"
          placeholder={t("addCompany.ownerIdPlaceholder", { defaultValue: "Owner ID (UUID)" })}
          value={formData.owner_id}
          onChange={handleChange}
          required
          className={styles.input}
        />

        {/* 🌍 Map Picker */}
        <div style={{ marginBottom: "1rem" }}>
          <MapPicker lat={location.lat} lng={location.lng} onChange={setLocation} />
        </div>

        <button type="submit" disabled={loading} className={styles.button}>
          {loading
            ? t("addCompany.creating", { defaultValue: "Creating..." })
            : t("addCompany.create", { defaultValue: "Create Company" })}
        </button>
      </form>
    </div>
  );
}
