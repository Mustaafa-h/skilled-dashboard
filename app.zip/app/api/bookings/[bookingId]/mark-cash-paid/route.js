export async function PUT(request, { params }) {
  const { bookingId } = params;

  try {
    const baseUrl = process.env.NEXT_PUBLIC_BOOKINGS_API_URL;
  const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiMWQ4ZTcxYy02YjEzLTRiNzYtODg0Yi1lMGRlODk5NTQwZmUiLCJwaG9uZSI6Iis5NjQ3NzEyMzQ1MzMzIiwiZW1haWwiOiJhZG1pbjI1MGZkZjlAZXhhbXBsZS5jb20iLCJuYW1lIjoiQWRtaW4gVXNlciIsImNvbXBhbnlJZCI6IjI1MGZkZjliLTk4NWEtNGY2MC05N2NlLTgyNjFiOGQ5ZmI3MSIsInJvbGUiOiJjb21wYW55X2FkbWluIiwic3RhdHVzIjoiYWN0aXZlIiwiaWF0IjoxNzUyOTcxOTA5LCJleHAiOjE3NTM1NzY3MDksImF1ZCI6ImhvbWUtc2VydmljZXMtdXNlcnMiLCJpc3MiOiJob21lLXNlcnZpY2VzLXBsYXRmb3JtIn0.612S-WHGAlSZSNtCjMmYYaE1rUynK7XIK1hAzGVv0AY';

    const res = await fetch(`${baseUrl}/api/v1/bookings/${bookingId}/mark-cash-paid`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        accept: "*/*",
      },
    });

    const data = await res.json();

    if (!res.ok) {
      return Response.json({ error: data.message || "Failed to mark cash paid" }, { status: res.status });
    }

    return Response.json(data);
  } catch (error) {
    console.error("mark-cash-paid error:", error);
    return Response.json({ error: "Server error while marking cash paid" }, { status: 500 });
  }
}
