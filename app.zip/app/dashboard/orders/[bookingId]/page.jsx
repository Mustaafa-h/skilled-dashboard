"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import styles from "@/app/ui/dashboard/orders/[id]/singleorder.module.css";
import { getCompanyWorkers } from "@/app/lib/api";
import { useTranslations } from "next-intl";

const SingleOrderPage = () => {
  const t = useTranslations();
  const companyId = (typeof window !== "undefined" ? localStorage.getItem("companyId") : null);
  const { bookingId } = useParams();

  const [booking, setBooking] = useState(null);
  const [workers, setWorkers] = useState([]);
  const [selectedWorker, setSelectedWorker] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchBooking = async () => {
    try {
      const res = await fetch(`/api/bookings/${bookingId}`);
      const data = await res.json();
      console.log("📦 Booking fetched:", data);
      setBooking(data.data);
    } catch (err) {
      console.error(" Failed to fetch booking:", err);
      setError(t("bookingFetchError", { defaultValue: "Failed to load booking" }));
    } finally {
      setLoading(false);
    }
  };

  const fetchWorkers = async () => {
    try {
      if (!companyId) return;
      const { data } = await getCompanyWorkers(companyId);
      console.log("👷 Workers fetched:", data);
      setWorkers((Array.isArray(data.data) ? data.data : []).filter(w => w.full_name || w.name));
      console.log("hhhh",data.data)
    } catch (err) {
      console.error(" Failed to fetch workers:", err);
    }
  };

  const assignWorker = async () => {
    try {
      const res = await fetch(`/api/bookings/${bookingId}/assign-worker`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          worker_id: selectedWorker,
          notes: "Assigned by admin",
        }),
      });
      const result = await res.json();
      console.log("👤 Worker assigned:", result);
      fetchBooking();
    } catch (err) {
      console.error("❌ Assign worker error:", err);
    }
  };

  const markCashPaid = async () => {
    try {
      const res = await fetch(`/api/bookings/${bookingId}/mark-cash-paid`, {
        method: "PUT",
      });
      const data = await res.json();
      console.log("💰 Cash marked as paid:", data);
      fetchBooking();
    } catch (err) {
      console.error("❌ Failed to mark cash paid:", err);
    }
  };

  const updateStatus = async (newStatus) => {
    try {
      const res = await fetch(`/api/bookings/${bookingId}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus, notes: `Marked ${newStatus}` }),
      });
      const result = await res.json();
      console.log("🔄 Status updated:", result);
      fetchBooking();
    } catch (err) {
      console.error("❌ Status update failed:", err);
    }
  };

  useEffect(() => {
    fetchBooking();
  }, [bookingId]);

  useEffect(() => {
    fetchWorkers();
  }, [bookingId]);

  if (loading) return <div>{t("loading")}</div>;
  if (error || !booking) return <div>{error || t("bookingNotFound")}</div>;

  const total = (
    parseFloat(booking.base_cost || 0) + parseFloat(booking.additional_cost || 0)
  ).toFixed(2);
  const payment = booking.payment || {};
  const address = booking.address || {};
  const canAssign = booking.status === "confirmed";

  return (
    <div className={styles.container}>
      <h2>{t("booking") + ` #${booking.booking_number}`}</h2>

      <div className={styles.section}>
        <strong>{t("address")}</strong>
        <div>{address.apartment}, {address.building}</div>
        <div>{address.street}, {address.district}</div>
        <div>{address.city}</div>
        <div>{t("lat")}: {address.lat} / {t("long")}: {address.long}</div>
      </div>

      <div className={styles.section}>
        <strong>{t("service")}</strong>
        <div>{t("serviceName")}: {booking.service_name}</div>
        <div>{t("subService")}: {booking.sub_service_name}</div>
        <div>{t("customerId")}: {booking.customer_id}</div>
      </div>

      {Array.isArray(booking.preferences) && booking.preferences.length > 0 && (
        <div className={styles.section}>
          <strong>{t("preferences")}</strong>
          <ul>
            {booking.preferences.map((pref) => (
              <li key={pref.id}>
                {pref.preference_type_name}: {pref.customer_value_display || pref.customer_value}
              </li>
            ))}
          </ul>
        </div>
      )}

      {booking.special_instructions && (
        <div className={styles.section}>
          <strong>{t("specialInstructions")}</strong>
          <div>{booking.special_instructions}</div>
        </div>
      )}

      <div className={styles.section}>
        <strong>{t("scheduleInfo")}</strong>
        <div>{t("preferredDate")}: {booking.preferred_date}</div>
        <div>{t("scheduledDate")}: {booking.scheduled_date || t("notScheduled")}</div>
        <div>{t("startTime")}: {booking.scheduled_start_time || "-"}</div>
        <div>{t("endTime")}: {booking.scheduled_end_time || "-"}</div>
      </div>

      <div className={styles.section}>
        <strong>{t("paymentInfo")}</strong>
        <div>{t("amount")}: {payment.amount} {payment.currency || "IQD"}</div>
        <div>{t("method")}: {payment.payment_method}</div>
        <div>{t("status")}: {payment.status}</div>
        {payment.payment_method === "cash_on_delivery" && payment.status === "pending" && (
          <button onClick={markCashPaid}>{t("markCashPaid")}</button>
        )}
      </div>

      <div className={styles.section}>
        <strong>{t("assignWorker")}</strong>
        {canAssign ? (
          <>
            <select
              value={selectedWorker}
              onChange={(e) => setSelectedWorker(e.target.value)}
            >
              <option value="">{t("selectWorker")}</option>
              {workers.map((w) => (
                <option key={w._id || w.id} value={w._id || w.id}>
                  {w.full_name || w.name || "Unnamed"}
                </option>
              ))}
            </select>
            <button onClick={assignWorker}>{t("assign")}</button>
          </>
        ) : (
          <p>{t("assignOnlyIfConfirmed")}</p>
        )}

      </div>

      {booking.status === "in_progress" && (
        <div className={styles.section}>
          <button onClick={() => updateStatus("completed")}>{t("markCompleted")}</button>
        </div>
      )}

      <div className={styles.sectionHighlight}>
        {t("totalCost")}: {total} IQD
      </div>
    </div>
  );
};

export default SingleOrderPage;
