"use client";

import { useState, useEffect } from "react";
import { supabase } from "@/app/lib/supabase";
import { addCompanyImage, getCompanyImages } from "@/app/lib/api";
import styles from "@/app/ui/dashboard/gallery/gallery.module.css";
import toast from "react-hot-toast";
import { useTranslations } from "next-intl";

export default function GalleryPage() {
  const t = useTranslations();
  const [images, setImages] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [file, setFile] = useState(null);
  const [description, setDescription] = useState("");

  const bucketName = "company-images";
  const companyId = (typeof window !== "undefined" ? localStorage.getItem("companyId") : null);

  const fetchImages = async () => {
    try {
      const { data } = await getCompanyImages(companyId);
      setImages(data.data);
    } catch (error) {
      console.error(error);
      toast.error(t("fetchImagesFailed"));
    }
  };

  useEffect(() => {
    fetchImages();
  }, []);

  const handleUpload = async () => {
    if (!file) {
      toast.error(t("selectFileFirst"));
      return;
    }
    if (!description.trim()) {
      toast.error(t("enterDescription"));
      return;
    }

    setUploading(true);
    const fileName = `${Date.now()}-${file.name}`;

    try {
      const { error: uploadError } = await supabase.storage
        .from(bucketName)
        .upload(`${companyId}/${fileName}`, file);

      if (uploadError) throw uploadError;

      const { data: urlData } = await supabase.storage
        .from(bucketName)
        .getPublicUrl(`${companyId}/${fileName}`);
      const publicUrl = urlData.publicUrl;

      await addCompanyImage(companyId, {
        url: publicUrl,
        description: description.trim(),
        image_type: "gallery",
        sort_order: 1,
      });

      toast.success(t("imageUploaded"));
      setFile(null);
      setDescription("");
      fetchImages();
    } catch (error) {
      console.error(error);
      toast.error(t("uploadFailed"));
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className={styles.container}>
      <h2>{t("companyGallery")}</h2>

      <div className={styles.controls}>
        <input
          type="file"
          accept="image/*"
          onChange={(e) => setFile(e.target.files[0])}
        />
        <input
          type="text"
          placeholder={t("enterImageDescription")}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <button onClick={handleUpload} disabled={uploading}>
          {uploading ? t("uploading") : t("upload")}
        </button>
      </div>

      <div className={styles.grid}>
        {images.map((image, idx) => (
          <div className={styles.card} key={image.id || idx}>
            <img src={image.url} alt={image.description || `Image ${idx}`} className={styles.image} />
            <p>{image.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
